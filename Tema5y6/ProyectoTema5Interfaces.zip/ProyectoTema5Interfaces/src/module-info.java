module ProyectoTema5Interfaces {
	requires javafx.controls;
	requires javafx.graphics;
	requires javafx.fxml;
	requires java.desktop;
	
	opens application to javafx.graphics, javafx.fxml;
	opens ejercicio2 to javafx.graphics, javafx.fxml;
	opens ejercicio3 to javafx.graphics, javafx.fxml;
	opens ejercicio4 to javafx.graphics, javafx.fxml;
	opens ejercicio6 to javafx.graphics, javafx.fxml;
	opens ejercicio7 to javafx.graphics, javafx.fxml;
	opens ejercicio8 to javafx.graphics, javafx.fxml;
	opens ejercicio9 to javafx.graphics, javafx.fxml;
	opens ejercicio10 to javafx.graphics, javafx.fxml;
}
