package ejercicio4;

import javafx.event.*;

import javafx.fxml.FXML;
import javafx.scene.control.Button;

public class Controller {
	@FXML
	private Button boton1,boton2,boton3,boton4,boton5;
	
	@FXML
	private void handleButtonClick(ActionEvent event) {
		String id = ((Button) event.getSource()).getId();
		System.out.println("Boton pulsado: " + id);
		
		switch(id) {
		case "Button1":
			System.out.println("Has pulsado el botón 1");
			break;
		case "Button2":
			System.out.println("Has pulsado el botón 2");
			break;
		case "Button3":
			System.out.println("Has pulsado el botón 3");
			break;
		case "Button4":
			System.out.println("Has pulsado el botón 4");
			break;	
		}
	}
}
