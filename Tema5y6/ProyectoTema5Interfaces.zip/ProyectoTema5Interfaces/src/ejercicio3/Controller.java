package ejercicio3;

import javafx.event.*;

import javafx.fxml.FXML;


public class Controller {
	@FXML
	private void handleButtonClick(ActionEvent event) {
		System.out.println("Se ha pulsado el botón");
	}
}
