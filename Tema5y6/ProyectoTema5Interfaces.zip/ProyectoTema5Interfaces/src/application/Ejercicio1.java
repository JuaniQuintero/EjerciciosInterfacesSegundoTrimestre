package application;

import javafx.application.Application;
import javafx.scene.Scene;
import javafx.scene.layout.BorderPane;
import javafx.stage.Stage;

public class Ejercicio1 extends Application{
	@Override
	public void init()throws Exception {
		super.init();
		System.out.println("Método init() llamado");
	}
	@Override
	public void start(Stage primaryStage) {
		try {
			BorderPane root = new BorderPane();
			Scene scene = new Scene(root,400,400);
			scene.getStylesheets().add(getClass().getResource("application.css").toExternalForm());
			primaryStage.setScene(scene);
			primaryStage.show();
			System.out.println("Método start() llamado");
		}catch(Exception e) {
			e.printStackTrace();
		}
		
	}
	@Override
	public void stop() throws Exception {
		// TODO Auto-generated method stub
		super.stop();
		System.out.println("Método stop() llamado");
	}
	
	public static void main(String [] args) {
		launch(args);
	}
}
